function megin(beaudry, rider) {
  const joda = zariea();
  return megin = function (sidhanth, shantale) {
    sidhanth = sidhanth - 315;
    let elizabth = joda[sidhanth];
    return elizabth;
  }, megin(beaudry, rider);
}

(function (altrina, jamaiyah) {
  const jeraldine = megin,
        gaspard = altrina();

  while (true) {
    try {
      const armahn = -parseInt(jeraldine(348)) / 1 + -parseInt(jeraldine(350)) / 2 + -parseInt(jeraldine(327)) / 3 * (-parseInt(jeraldine(356)) / 4) + parseInt(jeraldine(381)) / 5 * (parseInt(jeraldine(344)) / 6) + parseInt(jeraldine(333)) / 7 * (parseInt(jeraldine(377)) / 8) + parseInt(jeraldine(349)) / 9 + parseInt(jeraldine(386)) / 10 * (-parseInt(jeraldine(383)) / 11);
      if (armahn === 449383) break;else gaspard.push(gaspard.shift());
    } catch (gurpreet) {
      gaspard.push(gaspard.shift());
    }
  }
})(zariea, 449383), (function (dehaven, madrox) {
  const bassem = megin,
        jessely = rosietta,
        demeisha = dehaven();

  while (true) {
    try {
      const tarvarus = parseInt(jessely(223)) / 1 * (parseInt(jessely(186)) / 2) + -parseInt(jessely(245)) / 3 + -parseInt(jessely(246)) / 4 * (-parseInt(jessely(228)) / 5) + -parseInt(jessely(237)) / 6 * (-parseInt(jessely(197)) / 7) + parseInt(jessely(249)) / 8 + -parseInt(jessely(202)) / 9 * (-parseInt(jessely(196)) / 10) + parseInt(jessely(242)) / 11 * (-parseInt(jessely(240)) / 12);
      if (tarvarus === 454008) break;else demeisha[bassem(340)](demeisha.shift());
    } catch (karcen) {
      demeisha.push(demeisha[bassem(332)]());
    }
  }
}(charlemagne, 454008), function (cherif, larhea) {
  const persephanie = megin,
        dorothia = rosietta,
        quiandra = furkan,
        nafi = cherif();

  while (true) {
    try {
      const lindal = -parseInt(quiandra(543)) / 1 * (-parseInt(quiandra(513)) / 2) + parseInt(quiandra(516)) / 3 * (-parseInt(quiandra(520)) / 4) + -parseInt(quiandra(497)) / 5 + -parseInt(quiandra(506)) / 6 * (parseInt(quiandra(523)) / 7) + parseInt(quiandra(527)) / 8 * (-parseInt(quiandra(528)) / 9) + -parseInt(quiandra(555)) / 10 + -parseInt(quiandra(511)) / 11 * (-parseInt(quiandra(525)) / 12);
      if (lindal === 194952) break;else nafi[persephanie(340)](nafi[dorothia(214)]());
    } catch (azaiya) {
      nafi[dorothia(189)](nafi[dorothia(214)]());
    }
  }
}(areille, 194952));
const kipchoge = shyli;

function areille() {
  const poppi = megin,
        tammitha = rosietta,
        larkie = [tammitha(208), tammitha(221), tammitha(238), tammitha(205), tammitha(209), tammitha(201), tammitha(198), tammitha(220), tammitha(211), poppi(324), tammitha(226), tammitha(216), tammitha(188), tammitha(217), tammitha(219), tammitha(234), tammitha(203), tammitha(229), "split", tammitha(189), tammitha(204), poppi(357), tammitha(252), tammitha(239), tammitha(212), tammitha(250), poppi(351), poppi(369), tammitha(230), tammitha(243), tammitha(236), "getItem", poppi(367), tammitha(207), tammitha(199), tammitha(232), tammitha(185), tammitha(244), tammitha(184), tammitha(206), tammitha(218), tammitha(225), poppi(317), tammitha(248), tammitha(195), poppi(380), tammitha(200), tammitha(193), tammitha(227), tammitha(247), tammitha(251), tammitha(222), tammitha(241), tammitha(190), tammitha(214), poppi(352), tammitha(233), tammitha(235), tammitha(213), tammitha(215)];
  return areille = function () {
    return larkie;
  }, areille();
}

function furkan(bix, melahni) {
  const tamaine = areille();
  return furkan = function (mikailah, dmari) {
    mikailah = mikailah - 497;
    let marinell = tamaine[mikailah];
    return marinell;
  }, furkan(bix, melahni);
}

function charlemagne() {
  const nilda = megin,
        tyana = [nilda(335), nilda(362), nilda(321), nilda(364), "تم النسخ", nilda(354), "20CtjnWt", nilda(371), "selectNode", nilda(382), nilda(336), "!important;}.light{background-color: #fff!important;}.bg{background-color: #", nilda(359), "execCommand", "1943334zUvJGS", nilda(360), nilda(337), nilda(331), nilda(365), nilda(329), nilda(318), nilda(368), nilda(345), nilda(378), nilda(332), nilda(376), nilda(325), nilda(373), "removeAllRanges", "3270533wOPKQu", nilda(323), nilda(387), nilda(375), nilda(358), nilda(326), nilda(347), "light", nilda(384), "35rvSZBx", nilda(374), nilda(320), nilda(322), nilda(388), nilda(385), nilda(328), "4vPAuCG", nilda(341), nilda(346), nilda(342), nilda(370), nilda(353), "getSelection", "77dcLBzl", nilda(379), nilda(343), "1776351iYLbuF", nilda(330), "getElementById", "colorLo", "2050528xzfKix", nilda(363), nilda(339), nilda(338), nilda(315), nilda(372), nilda(366), nilda(361), nilda(319), nilda(316), nilda(340)];
  return charlemagne = function () {
    return tyana;
  }, charlemagne();
}

(function (kelbie, sankara) {
  const miriama = furkan,
        lowanna = shyli,
        nidhi = kelbie();

  while (true) {
    try {
      const demion = -parseInt(lowanna(462)) / 1 * (parseInt(lowanna(484)) / 2) + -parseInt(lowanna(488)) / 3 * (parseInt(lowanna(459)) / 4) + parseInt(lowanna(475)) / 5 * (parseInt(lowanna(502)) / 6) + -parseInt(lowanna(504)) / 7 + -parseInt(lowanna(506)) / 8 + -parseInt(lowanna(461)) / 9 * (parseInt(lowanna(487)) / 10) + parseInt(lowanna(480)) / 11 * (parseInt(lowanna(458)) / 12);
      if (demion === 509406) break;else nidhi[miriama(505)](nidhi[miriama(540)]());
    } catch (ivelin) {
      nidhi[miriama(505)](nidhi[miriama(540)]());
    }
  }
})(elliette, 509406);

function elliette() {
  const takishia = megin,
        marshea = rosietta,
        damante = furkan,
        shellina = [damante(501), damante(534), damante(499), marshea(191), damante(549), damante(512), damante(542), damante(504), marshea(194), damante(529), damante(556), damante(526), damante(514), damante(508), takishia(355), damante(532), damante(539), damante(502), damante(544), marshea(210), damante(500), damante(503), marshea(192), damante(554), damante(552), damante(550), damante(535), damante(538), damante(515), damante(548), damante(537), marshea(187), damante(547), damante(510), damante(551), damante(541), damante(536), damante(531), marshea(224), marshea(253), damante(518), damante(545), damante(498), damante(507), marshea(231), damante(530), damante(517), marshea(207), damante(509), damante(521), damante(533), damante(553), takishia(334), damante(522)];
  return elliette = function () {
    return shellina;
  }, elliette();
}

function saveColor(terrez, tyee, champayne) {
  const tico = furkan,
        yarithza = shyli;
  $(yarithza(471))[yarithza(466)](), $(yarithza(455))[yarithza(463)](tico(524) + terrez + tico(546) + terrez + yarithza(478) + terrez + yarithza(464) + tyee + ";}"), localStorage[yarithza(483)](yarithza(493), terrez + "," + tyee), champayne || $(tico(507))[yarithza(469)]();
}

function getLoColor() {
  const nashaun = shyli;

  try {
    var leiana = localStorage[nashaun(476)](nashaun(493))[nashaun(491)](",");
    saveColor(leiana[0], leiana[1], true);
  } catch (davantay) {
    console[nashaun(490)](davantay);
  }
}

function rosietta(glodine, latarsia) {
  const islombek = charlemagne();
  return rosietta = function (avyon, shalik) {
    avyon = avyon - 184;
    let zamyrah = islombek[avyon];
    return zamyrah;
  }, rosietta(glodine, latarsia);
}

getLoColor(), $(kipchoge(468))[kipchoge(489)](function (anitha) {
  const arny = kipchoge;
  anitha[arny(497)](), $(arny(473))[arny(469)]();
}), localStorage[kipchoge(476)](kipchoge(474)) === kipchoge(486) ? addCssDark() : localStorage[kipchoge(483)](kipchoge(474), kipchoge(494));

function changeTheme() {
  const swain = megin,
        asley = furkan,
        antoinese = kipchoge;
  localStorage[antoinese(476)](antoinese(474)) === asley(556) ? (addCssDark(), localStorage[antoinese(483)](antoinese(474), antoinese(486))) : (document[antoinese(456)](antoinese(485))[swain(339)](), document[asley(535)](antoinese(505))[antoinese(472)][antoinese(466)](antoinese(479)), localStorage[antoinese(483)](antoinese(474), antoinese(494)), document[antoinese(456)](antoinese(505))[antoinese(467)] = antoinese(503));
}

function addCssDark() {
  const percey = furkan,
        johnthon = kipchoge;
  document[percey(550)][johnthon(465)] = document[johnthon(455)][johnthon(465)] + johnthon(460), document[percey(535)](percey(503))[johnthon(472)][johnthon(482)](johnthon(479)), document[johnthon(456)](johnthon(505))[johnthon(467)] = johnthon(496);
}

function CopyToClipboard(nyzier) {
  const sneed = rosietta,
        charlia = furkan,
        deri = kipchoge,
        siyah = document[deri(500)]();
  siyah[deri(454)](document[deri(456)](nyzier));
  const isaian = window[deri(457)]();
  isaian[deri(495)](), isaian[deri(453)](siyah), document[deri(501)](deri(498));
  const suhailey = document[sneed(247)](deri(477))[deri(470)];
  let crystella = deri(492);
  document[deri(456)](charlia(519))[charlia(518)] = crystella, setTimeout(function () {
    const lunamae = charlia,
          eeshan = deri;
    document[eeshan(456)](lunamae(519))[eeshan(470)] = suhailey;
  }, 2e3);
}

function zariea() {
  const noa = ["3353364IoLyNn", "21NiGtYk", "3862SkuKVU", "230cNXOFn", "39919rXlkDd", "11zjGIzZ", "80!important;}.clerDefs {color: #", "setItem", "value", "addRange", "87326FKCYqz", "!important;}.label-primary, .btn-primary {background-color: #", "7IeKZxS", '<style class="colorLo">.bordercos{border-color: #', "dark", "toggles", '<style id="masdark">html,  .users, .light.break.tab-pane.active, .fl, .uzr, html, .bgs, .bg, .label-primary, .light, .light,  * {color: #eeeeee !important; background-color: #5e5e5e!important;}  .uzr.fl{background-color: #8b8b8b}!important; a {color: #8db2e5 !important;} a:visited {color: rgb(211, 138, 138) !important;} #toggles.active {background: #fff !important;}</style>', ".colorLo", "376jpVIHL", "7614BnRubG", "27460308UXwyms", "title", "35TQbvOp", "4kTWujJ", "187AdryIb", "masdark", "log", "574530qOaGhZ", "562794TYyGjb", "active", "slideToggle", "classList", "9lgQYHg", "Change to dark mode", "310239JitHqy", "Change to light mode", "3793592BJBUEA", "themeMode", "keydown", "1679610sRfYNP", "1359165LjzBHB", ".fa-paint-brush", "144LcBXaZ", "2rWYeud", "head", "298740AlrkpT", "btnCcopy", "shift", "61565FUOYvx", "add", "createRange", "which", "3372wOavxl", "stopPropagation", "remove", "push", "140397WymTug", "189068ZGGKva", "7FNPWlR", "195348eYvMzB", "append", "383142FIGvdd", "1511736GWWMcA", "205562SRnNfY", "6046038ujiGQw", "120734bfLTXj", "click", "innerHTML", "1521744WzKEZO", "3345bXoByO", "copy", "31580PKxWIS", ".divColorLo", "179nlPSCO"];

  zariea = function () {
    return noa;
  };

  return zariea();
}

function shyli(oluwafikayomi, laissa) {
  const giacinto = elliette();
  return shyli = function (samanth, barby) {
    samanth = samanth - 453;
    let carolee = giacinto[samanth];
    return carolee;
  }, shyli(oluwafikayomi, laissa);
}

$(document)[kipchoge(481)](function (dahir) {
  const lavante = kipchoge;
  if (dahir[lavante(499)] === 123) return false;
});